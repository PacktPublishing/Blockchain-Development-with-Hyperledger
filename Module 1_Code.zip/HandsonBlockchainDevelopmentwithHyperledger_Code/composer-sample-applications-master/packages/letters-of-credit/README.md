## Letter of Credit Sample Application

To deploy this application, run the provided install script by using the following command:

`./installers/install.sh`

This will open the tutorial and the four banking tabs that make up the application, as well as Playground and the REST server.